$(document).ready(function() { 
    App.run();
});